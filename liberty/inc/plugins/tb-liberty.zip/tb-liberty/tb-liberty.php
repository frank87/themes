<?php

/*
Plugin Name: Theme Blossom Issues
Plugin URL: http://themeblossom.net
Description: Issues...
Version: 2.0
Author: Theme Blossom
Author URI: http://themeblossom.net
*/

add_action( 'admin_menu', 'tb_liberty_add_admin_menu' );
add_action( 'admin_init', 'tb_liberty_settings_init' );


function tb_liberty_add_admin_menu(  ) { 

	add_menu_page( 'ThemeBlossom Plugins', 'ThemeBlossom Plugins', 'manage_options', 'liberty_plugins', 'tb_liberty_options_page' );

}


function tb_liberty_settings_init(  ) { 

	register_setting( 'pluginPage', 'tb_liberty_settings' );

	add_settings_section(
		'tb_liberty_pluginPage_section', 
		__( 'Issues Settings', 'liberty' ), 
		'tb_liberty_settings_section_callback', 
		'pluginPage'
	);

	add_settings_field( 
		'issue_cpt', 
		__( 'Issues DB entry - leave blank unless you know what are you doing.', 'liberty' ), 
		'issue_cpt_render', 
		'pluginPage', 
		'tb_liberty_pluginPage_section' 
	);

	add_settings_field( 
		'issue_singular', 
		__( 'Issues Singular (i.e. Issue)', 'liberty' ), 
		'issue_singular_render', 
		'pluginPage', 
		'tb_liberty_pluginPage_section' 
	);

	add_settings_field( 
		'issue_plural', 
		__( 'Issues Plural (i.e. Issues)', 'liberty' ), 
		'issue_plural_render', 
		'pluginPage', 
		'tb_liberty_pluginPage_section' 
	);

	add_settings_field( 
		'issue_slug', 
		__( 'Issues Slug - you will need to regenerate permalinks structure after the change.', 'liberty' ), 
		'issue_slug_render', 
		'pluginPage', 
		'tb_liberty_pluginPage_section' 
	);


}


function issue_cpt_render(  ) { 

	$options = get_option( 'tb_liberty_settings' );
	if (isset($options['issue_cpt'])) {
		$issues_cpt_option = $options['issue_cpt'];
	} else {
		$issues_cpt_option = '';
	}
	?>
	<input type='text' name='tb_liberty_settings[issue_cpt]' value='<?php echo $issues_cpt_option; ?>'>
	<?php

}


function issue_singular_render(  ) { 

	$options = get_option( 'tb_liberty_settings' );
	if (isset($options['issue_singular'])) {
		$issues_singular_option = $options['issue_singular'];
	} else {
		$issues_singular_option = '';
	}
	?>
	<input type='text' name='tb_liberty_settings[issue_singular]' value='<?php echo $issues_singular_option; ?>'>
	<?php

}


function issue_plural_render(  ) { 

	$options = get_option( 'tb_liberty_settings' );
	if (isset($options['issue_plural'])) {
		$issues_plural_option = $options['issue_plural'];
	} else {
		$issues_plural_option = '';
	}
	?>
	<input type='text' name='tb_liberty_settings[issue_plural]' value='<?php echo $issues_plural_option; ?>'>
	<?php

}


function issue_slug_render(  ) { 

	$options = get_option( 'tb_liberty_settings' );
	if (isset($options['issue_slug'])) {
		$issues_slug_option = $options['issue_slug'];
	} else {
		$issues_slug_option = '';
	}
	?>
	<input type='text' name='tb_liberty_settings[issue_slug]' value='<?php echo $issues_slug_option; ?>'>
	<?php

}


function tb_liberty_settings_section_callback(  ) { 

	echo __( 'Change specific fields or leave them empty to use default settings.<br><br>If you change slugs, please make sure to regenerate permalinks of your site.', 'liberty' );

}


function tb_liberty_options_page(  ) { 

	?>
	<form action='options.php' method='post'>

		<h1>ThemeBlossom Plugins Settings</h1>

		<br><br>

		<?php
		settings_fields( 'pluginPage' );
		do_settings_sections( 'pluginPage' );
		submit_button();
		?>

	</form>
	<?php

}

require_once('themeblossom_issues.php');

?>