<?php

add_action( 'init', 'register_cpt_issue', 1 );

$liberty_plugin_option = get_option( 'tb_liberty_settings' );

if (isset($liberty_plugin_option) && isset($liberty_plugin_option['issue_cpt']) && $liberty_plugin_option['issue_cpt'] != '') {
    define('THEMEBLOSSOM_ISSUES_CPT', $liberty_plugin_option['issue_cpt']);
} else {
    define("THEMEBLOSSOM_ISSUES_CPT", "issue");
}

if (isset($liberty_plugin_option) && isset($liberty_plugin_option['issue_singular']) && $liberty_plugin_option['issue_singular'] != '') {
    $singular = $liberty_plugin_option['issue_singular'];
    if ($singular == '') {
        $singular = 'Issue';
    }
} else {
    $singular = 'Issue';
}
define("THEMEBLOSSOM_ISSUES_SINGULAR", $singular);

if (isset($liberty_plugin_option) && isset($liberty_plugin_option['issue_plural']) && $liberty_plugin_option['issue_plural'] != '') {
    define('THEMEBLOSSOM_ISSUES_PLURAL', $liberty_plugin_option['issue_plural']);
} else {
    define("THEMEBLOSSOM_ISSUES_PLURAL", "Issues");
}

if (isset($liberty_plugin_option) && isset($liberty_plugin_option['issue_slug']) && $liberty_plugin_option['issue_slug'] != '') {
    define('THEMEBLOSSOM_ISSUES_SLUG', $liberty_plugin_option['issue_slug']);
} else {
    define('THEMEBLOSSOM_ISSUES_SLUG', 'issue');
}

define("THEMEBLOSSOM_ISSUE_TAX", "issues_categories");
define("THEMEBLOSSOM_ISSUE_TAX_SINGULAR", "Issue Category");
define("THEMEBLOSSOM_ISSUE_TAX_PLURAL", "Issue Categories");

function register_cpt_issue() {

    $labels = array( 
        'name' => _x( THEMEBLOSSOM_ISSUES_PLURAL, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'singular_name' => _x( THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'add_new' => _x( 'Add New', THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'add_new_item' => _x( 'Add New ' . THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'edit_item' => _x( 'Edit ' . THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'new_item' => _x( 'New ' . THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'view_item' => _x( 'View ' . THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'search_items' => _x( 'Search ' . THEMEBLOSSOM_ISSUES_PLURAL, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'not_found' => _x( 'No ' . THEMEBLOSSOM_ISSUES_PLURAL . ' Found', THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'not_found_in_trash' => _x( 'No ' . THEMEBLOSSOM_ISSUES_PLURAL . ' Found in Trash', THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'parent_item_colon' => _x( 'Parent' . THEMEBLOSSOM_ISSUES_SINGULAR, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
        'menu_name' => _x( THEMEBLOSSOM_ISSUES_PLURAL, THEMEBLOSSOM_ISSUES_CPT, 'liberty' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => false,
        
        'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
        'taxonomies' => array( THEMEBLOSSOM_ISSUE_TAX ),
        
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
		
		'menu_icon' => 'dashicons-hammer',
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array('slug' => THEMEBLOSSOM_ISSUES_SLUG),
        'capability_type' => 'post'
    );

    register_post_type( THEMEBLOSSOM_ISSUES_CPT, $args );   $labels = array( 
        'name' => _x( THEMEBLOSSOM_ISSUE_TAX_PLURAL, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'singular_name' => _x( 'Project Category', THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'search_items' => _x( 'Search', THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'popular_items' => _x( 'Popular ' . THEMEBLOSSOM_ISSUE_TAX_PLURAL, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'all_items' => _x( 'All', THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'parent_item' => _x( 'Parent ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'parent_item_colon' => _x( 'Parent ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR . ':', THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'edit_item' => _x( 'Edit ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'update_item' => _x( 'Update ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'add_new_item' => _x( 'Add New ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'new_item_name' => _x( 'New ' . THEMEBLOSSOM_ISSUE_TAX_SINGULAR, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'separate_items_with_commas' => _x( 'Separate ' . THEMEBLOSSOM_ISSUE_TAX_PLURAL . ' with Commas', THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'add_or_remove_items' => _x( 'Add or Remove ' . THEMEBLOSSOM_ISSUE_TAX_PLURAL, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'choose_from_most_used' => _x( 'Choose from the Most Used ' . THEMEBLOSSOM_ISSUE_TAX_PLURAL, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
        'menu_name' => _x( THEMEBLOSSOM_ISSUE_TAX_PLURAL, THEMEBLOSSOM_ISSUE_TAX, 'liberty' ),
    );

    $args = array( 
        'labels' => $labels,
        'public' => true,
        'show_in_nav_menus' => false,
        'show_ui' => true,
        'show_tagcloud' => true,
        'show_admin_column' => false,
        'hierarchical' => true,

        'rewrite' => true,
        'query_var' => true
    );

    register_taxonomy( THEMEBLOSSOM_ISSUE_TAX, array( THEMEBLOSSOM_ISSUES_CPT ), $args );

	add_filter( 'manage_edit-' . THEMEBLOSSOM_ISSUES_CPT . '_columns', 'set_custom_edit_issue_columns' );
	add_action( 'manage_' . THEMEBLOSSOM_ISSUES_CPT . '_posts_custom_column' , 'custom_issue_column', 10, 2 );
}

/*-----------------------CUSTOM COLUMNS-----------------------*/
function set_custom_edit_issue_columns($columns) {
	$columns = array(
		"cb"			=>	"<input type=\"checkbox\" />",
		"title"			=>	__("Name", 'liberty'),
		"_tb_issue_thumbnail"		=>	__("Preview Image", 'liberty'),
        "_tb_issue_category"      =>  __("Category", 'liberty'),
	);

	return $columns;
}

function custom_issue_column( $column, $post_id ) {
    switch ( $column ) {

        case '_tb_issue_thumbnail' :
			if (has_post_thumbnail($post_id)) the_post_thumbnail('thumbnail');
            
            break;

        case '_tb_issue_category' :
            $gcats = get_the_terms($post_id, THEMEBLOSSOM_ISSUE_TAX);
            if (!empty($gcats))
            {
                $gcatArray = array();
                foreach ($gcats as $gcat)   $gcatArray[] = $gcat->name;

                echo implode($gcatArray, ", ");
            }
            break;
    }
}

?>